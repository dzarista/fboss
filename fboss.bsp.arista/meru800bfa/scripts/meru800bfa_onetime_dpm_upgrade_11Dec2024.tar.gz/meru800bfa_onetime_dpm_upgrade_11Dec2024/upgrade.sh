#!/bin/bash

stop_services() {
   # Unbind drivers
   systemctl stop sensor_service
   systemctl stop qsfp_service
   systemctl stop platform_manager
   rmmod isl68137
}

do_upgrade_device() {
   dev_id="$1"

   case "$dev_id" in
      "0x50"|"0x51"|"0x52"|"0x53")
         echo "Valid dev_id found. proceeding."
         ;;
      *)
         echo "invalid device $dev_id"
         exit 1
         ;;
   esac

   fw_file="Blackcomb-Pol-"$dev_id".hex"
   mfr_rev="$(i2cget -f -y 11 "$dev_id" 0x9b s | sed 's/0x//g' | awk '{print $1}')"

   # Make sure we only upgrade <= 06 to rev07
   case "$mfr_rev" in
      "01"|"02""03"|"04"|"05"|"06")
         echo "Firmware is outdated with $mfr_rev on $dev_id, upgrading!"
         # Program device, busAdd in hex
         python3 meru_program_isl.py -c isl68226 \
            -b b -a $dev_id --config $fw_file || exit 1
         ;;
      "07")
         echo "Firmware is matching 07 on $dev_id, no upgrade needed!"
         ;;
      *)
         echo "invalid firmware, skipping upgrade"
         exit 1
         ;;
   esac
}


stop_services
do_upgrade_device 0x50
do_upgrade_device 0x51
do_upgrade_device 0x52
do_upgrade_device 0x53

echo "You must powercycle for the changes to take effect!"
