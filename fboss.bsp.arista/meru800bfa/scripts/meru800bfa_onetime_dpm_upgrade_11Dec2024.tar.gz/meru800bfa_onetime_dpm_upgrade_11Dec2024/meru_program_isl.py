#!/usr/bin/env python3
# Copyright (c) 2020 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

import argparse
import ctypes
import os
import posix
import struct
import sys
import time
import zlib

from fcntl import ioctl

### LINUX SMBus CLASS ###

I2C_RDWR = 0x0707
I2C_FUNCS = 0x0705
I2C_SLAVE = 0x0703
I2C_SLAVE_FORCE = 0x0706
I2C_SLAVE = 0x0703
I2C_SMBUS = 0x0720 # SMBus-level access

# smbus_access read or write markers
I2C_SMBUS_READ = 1
I2C_SMBUS_WRITE = 0

# SMBus transaction types (size parameter in the above functions)
#   Note: these no longer correspond to the (arbitrary) PIIX4 internal codes!

I2C_SMBUS_QUICK = 0
I2C_SMBUS_BYTE = 1
I2C_SMBUS_BYTE_DATA = 2
I2C_SMBUS_WORD_DATA = 3
I2C_SMBUS_PROC_CALL = 4
I2C_SMBUS_BLOCK_DATA = 5
I2C_SMBUS_I2C_BLOCK_BROKEN = 6
I2C_SMBUS_BLOCK_PROC_CALL = 7 # SMBus 2.0
I2C_SMBUS_I2C_BLOCK_DATA = 8

I2C_FUNC_I2C                    = 0x00000001
I2C_FUNC_10BIT_ADDR             = 0x00000002
I2C_FUNC_PROTOCOL_MANGLING      = 0x00000004 # I2C_M_{REV_DIR_ADDR,NOSTART,..}
I2C_FUNC_SMBUS_PEC              = 0x00000008
I2C_FUNC_SMBUS_BLOCK_PROC_CALL  = 0x00008000 # SMBus 2.0
I2C_FUNC_SMBUS_QUICK            = 0x00010000
I2C_FUNC_SMBUS_READ_BYTE        = 0x00020000
I2C_FUNC_SMBUS_WRITE_BYTE       = 0x00040000
I2C_FUNC_SMBUS_READ_BYTE_DATA   = 0x00080000
I2C_FUNC_SMBUS_WRITE_BYTE_DATA  = 0x00100000
I2C_FUNC_SMBUS_READ_WORD_DATA   = 0x00200000
I2C_FUNC_SMBUS_WRITE_WORD_DATA  = 0x00400000
I2C_FUNC_SMBUS_PROC_CALL        = 0x00800000
I2C_FUNC_SMBUS_READ_BLOCK_DATA  = 0x01000000
I2C_FUNC_SMBUS_WRITE_BLOCK_DATA = 0x02000000
I2C_FUNC_SMBUS_READ_I2C_BLOCK   = 0x04000000 # I2C-like block xfer
I2C_FUNC_SMBUS_WRITE_I2C_BLOCK  = 0x08000000 # w/ 1-byte reg. addr.
# For I2C read with no start in between the messages.
I2C_FUNC_I2C_RD_WITH_NOSTART    = 0x4001

I2C_FUNC_SMBUS_BYTE = (I2C_FUNC_SMBUS_READ_BYTE | \
                       I2C_FUNC_SMBUS_WRITE_BYTE)
I2C_FUNC_SMBUS_BYTE_DATA = (I2C_FUNC_SMBUS_READ_BYTE_DATA | \
                            I2C_FUNC_SMBUS_WRITE_BYTE_DATA)
I2C_FUNC_SMBUS_WORD_DATA = (I2C_FUNC_SMBUS_READ_WORD_DATA | \
                            I2C_FUNC_SMBUS_WRITE_WORD_DATA)
I2C_FUNC_SMBUS_BLOCK_DATA = (I2C_FUNC_SMBUS_READ_BLOCK_DATA | \
                             I2C_FUNC_SMBUS_WRITE_BLOCK_DATA)
I2C_FUNC_SMBUS_I2C_BLOCK = (I2C_FUNC_SMBUS_READ_I2C_BLOCK | \
                               I2C_FUNC_SMBUS_WRITE_I2C_BLOCK)

class i2c_smbus_data( ctypes.Union ):
   _fields_ = [ ( 'byte', ctypes.c_uint8 ),
                ( 'word', ctypes.c_uint16 ),
                ( 'block', ctypes.c_uint8 * 34 ) ]

class i2c_smbus_data1( ctypes.Union ):
   _fields_ = [ ( 'byte', ctypes.c_uint8 ),
                ( 'word', ctypes.c_uint16 ),
                ( 'block', ctypes.c_uint8 * 2 ) ]

class i2c_smbus_ioctl_data( ctypes.Structure ):
   _fields_ = [ ( 'read_write', ctypes.c_uint8 ),
                ( 'command', ctypes.c_uint8 ),
                ( 'size', ctypes.c_int ),
                ( 'data', ctypes.POINTER( i2c_smbus_data ) ) ]

class i2c_msg( ctypes.Structure ):
   _fields_ = [
                ( 'addr', ctypes.c_uint16 ),
                ( 'flags', ctypes.c_uint16 ),
                ( 'len', ctypes.c_uint16 ),
                ( 'buf', ctypes.POINTER( i2c_smbus_data ) ) ]

class i2c_rdwr_ioctl_data( ctypes.Structure ):
   _fields_ = [
                ( 'msgs', ctypes.POINTER( i2c_msg *2 ) ),
                ( 'nmsgs', ctypes.c_uint32 ),
              ]

class LinuxSmbusHam:
   ''' This Ham is not based on DosLib.Ham because currently
   it takes >2 to import it. Should be fixed when SmbusUtil removed completely'''
   def __init__( self, busNumber, deviceAddr, addrSize=1 ):
      self.addSize = addrSize
      self.busNumber = busNumber
      self.fd = -1
      self.filename = ''
      self._funcs = None
      self.addrSize = addrSize
      self.deviceAddr = deviceAddr

      # open the i2c fd
      self.open()

      # setSlaveAddr
      force = False
      ioctl( self.fd, I2C_SLAVE_FORCE if force else I2C_SLAVE, deviceAddr )


   @property
   def funcs( self ):
      if self._funcs:
         return self._funcs
      ul = ctypes.c_ulong()
      ioctl( self.fd, I2C_FUNCS, ul )
      return ul.value

   @property
   def hasReceiveByte( self ):
      return self.funcs & I2C_FUNC_SMBUS_READ_BYTE != 0

   @property
   def hasSendByte( self ):
      return self.funcs & I2C_FUNC_SMBUS_WRITE_BYTE != 0

   @property
   def hasReadByteData( self ):
      return self.funcs & I2C_FUNC_SMBUS_READ_BYTE_DATA != 0

   @property
   def hasWriteByteData( self ):
      return self.funcs & I2C_FUNC_SMBUS_READ_WORD_DATA != 0

   @property
   def functionality( self ):
      if self.funcs & I2C_FUNC_I2C:
         ret = 'adt_i2c'
      elif self.funcs & ( I2C_FUNC_SMBUS_BYTE |
                          I2C_FUNC_SMBUS_BYTE_DATA |
                          I2C_FUNC_SMBUS_WORD_DATA ):
         ret = 'adt_smbus'
      else:
         ret = 'adt_dummy'

      return ret

   def open( self ):
      def tryOpenFile( filename ):
         try:
            self.filename = filename
            return posix.open( filename, os.O_RDWR )
         except OSError:
            return -1
      self.fd = tryOpenFile( '/dev/i2c/%d' % self.busNumber )
      if self.fd < 0:
         self.fd = tryOpenFile( '/dev/i2c-%d' % self.busNumber )
      if self.fd < 0:
         raise OSError

   def close( self ):
      posix.close( self.fd )


   def read8( self, command ):
      data = self.smbusAccess( I2C_SMBUS_READ,
                               command, I2C_SMBUS_BYTE_DATA )
      return data.contents.byte & 0xff

   def read16( self, command ):
      data = self.smbusAccess( I2C_SMBUS_READ,
                               command, I2C_SMBUS_WORD_DATA )
      return data.contents.word & 0xffff

   def write8( self, command, data ):
      _data = i2c_smbus_data()
      _data.byte = data # pylint: disable-msg=W0201
      self.smbusAccess( I2C_SMBUS_WRITE,
                        command, I2C_SMBUS_BYTE_DATA, _data )

   def write16( self, command, data ):
      _data = i2c_smbus_data()
      _data.word = data # pylint: disable-msg=W0201
      self.smbusAccess( I2C_SMBUS_WRITE,
                        command, I2C_SMBUS_WORD_DATA, _data )

   def read32( self, command ):
      return self.readBlock( command, 4 )

   def read32String( self, command ):
      return [ chr(x) for x in self.readBlock( command, 4 ) ]

   def write32( self, command, data ):
      assert len(data) == 4
      return self.writeSequence( command, data )

   def readBlock( self, command, size ):
      assert size <= 32
      _data = i2c_smbus_data()
      _data.byte = size # pylint: disable=attribute-defined-outside-init
      data = self.smbusAccess( I2C_SMBUS_READ, command,
                               I2C_SMBUS_I2C_BLOCK_DATA, _data )
      return data.contents.block[ 1 : 1 + data.contents.block[ 0 ] ]

   # Assuming 1 byte addressed part below
   # For a 2 byte addressed part populate:
   #    dataArray[0] with address[7:0] and
   #    addr with address[15:8]
   def writeI2cBlock( self, addr, dataArray ):
      # pylint: disable-msg=W0201
      numBytes = len( dataArray )
      assert numBytes < 34
      assert addr <= 0xff
      ar = i2c_smbus_ioctl_data()
      ar.read_write = I2C_SMBUS_WRITE
      ar.command = addr
      data = i2c_smbus_data()
      # Byte count itself not transmitted, used by
      # controller to track buffer size
      data.block[0] = numBytes
      for offset in range( numBytes ):
         data.block[ 1+offset ] = dataArray[ offset ]
      ar.size = I2C_SMBUS_I2C_BLOCK_DATA
      ar.data = ctypes.pointer( data )
      #  print( 'smbusAccess rw:{} c:{} s:{} byte:{} block: {}'.format(
         #  ar.read_write, hex(ar.command),
         #  ar.size, data.byte, [ x for x in data.block ] ) )
      ioctl( self.fd, I2C_SMBUS , ar )
      return

   def quickCommand( self ): # not tested
      ''' put slave address on the bus and a then write bit and stop bit '''
      self.smbusAccess( I2C_SMBUS_WRITE, 0, I2C_SMBUS_QUICK )

   def sendByte( self, command ): # not tested
      ''' write one byte. it could be a register address without data '''
      self.smbusAccess( I2C_SMBUS_WRITE, command, I2C_SMBUS_BYTE )

   def receiveByte( self ):
      data = self.smbusAccess( I2C_SMBUS_READ, 0, I2C_SMBUS_BYTE )
      return data.contents.byte & 0xff

   # since there is no support for I2C sequence read/write, these methods
   # will scan the blocks by advancing the address in strides

   def readSequenceStr( self, address, count ):
      return ''.join( chr( x ) for x in self.readiter( address, address + count ) )

   def readSequence( self, address, count ):
      return unpackLong( self.readSequenceStr( address, count ), endian='little' )

   def writeSequence( self, address, data ):
      self.writeI2cBlock( address, data )

   def writeSequenceStr( self, address, data ):
      dataArray = [ ord(x) for x in data ]
      self.writeI2cBlock( address, dataArray )

   def readiter( self, startAddress, endAddress ):
      ''' with readiter we can be used to search the string as we read word by read
      from the device. This can save time if we find what we are looking for without
      reading a whole block '''
      address = startAddress
      phase = True
      for address in range( startAddress, endAddress ):
         if phase:
            value = self.read16( address )
            yield value & 0xff
         else:
            yield ( value >> 8 ) & 0xff
         phase = not phase


   # pylint: disable-msg=W0201
   def smbusAccess( self, read_write, command, size, data=None ):
      smbusArg = i2c_smbus_ioctl_data()
      smbusArg.read_write = read_write
      smbusArg.command = command
      smbusArg.size = size
      if not data:
         data = i2c_smbus_data()
      smbusArg.data = ctypes.pointer( data )
      #  print( 'smbusAccess rw:{} c:{} s:{} byte:{} block: {}'.format(
         #  smbusArg.read_write, hex(smbusArg.command),
         #  smbusArg.size, data.byte, [ x for x in data.block ] ) )

      if ioctl( self.fd, I2C_SMBUS, smbusArg ) == -1:
         raise OSError( "failed to send data on the i2c bus" )
      return smbusArg.data


######## ISL CODE ######

def _byteReverse( word ):
   return struct.unpack( "<I", struct.pack(">I", word ) )[0]

def packLong( num, endian, byteCount ):
   """Pack a Python long into a string."""

   if endian not in ( 'big', 'little' ):
      raise Exception( "Unknown endian", endian )
   widthBits = num.bit_length()
   if widthBits / 8.0  > byteCount:
      raise Exception( "byteCount %d is not enough to contain Long %d"
                              % ( byteCount, num ) )

   packed = ""
   while byteCount:
      packed += chr( num & 0xFF )
      num >>= 8
      byteCount -= 1

   if endian == "big":
      packed = packed[ ::-1 ]

   return packed

def unpackLong( buf, endian ):
   """Unpack a string into a Python long."""

   if endian not in ( 'big', 'little' ):
      raise Exception( "Unknown endian", endian )

   unpacked = [ ord(i) for i in buf ]
   if endian == "little":
      unpacked.reverse()

   result = 0
   while unpacked:
      result = ( result << 8 ) | unpacked.pop( 0 )
   return result

class DmaIndirectHam:
   def __init__( self, wrappedHam, dmaAddrReg, dmaDataReg ):
      self._wrappedHam = wrappedHam
      self._currentDmaAddr = 0xFFFF
      self.dmaAddrReg = dmaAddrReg
      self.dmaDataReg = dmaDataReg

   def _setDmaAddr( self, addr ):
      if addr != self._currentDmaAddr:
         self._wrappedHam.write16( self.dmaAddrReg, addr )
         time.sleep( 100e-3 )
         self._currentDmaAddr = addr

   def read( self, addr ):
      self._setDmaAddr( addr )
      return unpackLong( self._wrappedHam.read32String(
                         self.dmaDataReg ), 'little' )

   def write( self, addr, data, endian='little' ):
      self._setDmaAddr( addr )
      dataLong = packLong( data, endian, 4 )

      self._wrappedHam.writeSequenceStr( self.dmaDataReg, dataLong )

class Isl68226:
   dmaAddrReg = 0xC7
   dmaDataReg = 0xC5
   chipDesc = "Isl68226"
   configPointerCode = 'C6'
   configPointerVal1 = '8AF5E738'
   configPointerVal2 = 'C605ABE0'

   def __init__( self, busId, address, initHam=False, dryRun=True ):
      self.ham = None
      self.dmaHam = None
      self.dryRun = dryRun
      if initHam:
         self.ham = LinuxSmbusHam( busId, address )
         self.dmaHam = DmaIndirectHam( self.ham, self.dmaAddrReg, self.dmaDataReg )

   def calculateConfigCrc( self, configFile ):
      assert configFile,  "need to specify config file"
      try:
         f = open( configFile )
      except OSError:
         raise Exception( "Unable to open config file %s" % configFile )

      beginCrc = False
      crc = 0
      count = 0
      for line in f:
         parsedLine = ''.join( filter( lambda x: x in '0123456789ABCDEFabcdef',
                                       line ) )
         code = parsedLine[6:8]
         data = parsedLine[8:-2]
         if beginCrc and count != 357:
            if count == 0:
               dataCopy = '00'+data[2:]
               dataStr = ''.join( [ chr( int(dataCopy[i:i+2], 16) ) \
                              for i in range(0,len(dataCopy), 2 ) ] )
            elif count == 318: # line 599. Insert project CRC.
               data = self.calculateProjectCrc(configFile)
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            else:
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            crc = zlib.crc32( dataStr, crc ) & 0xffffffff
            count += 1
         if code == self.configPointerCode  and \
            data in [ self.configPointerVal1, self.configPointerVal2 ]:
            beginCrc = True
      assert beginCrc, 'OTP START string not found in hex file'
      return '%08X' % _byteReverse( crc )

   def calculateProjectCrc( self, configFile ):
      assert configFile,  "need to specify config file"
      try:
         f = open( configFile )
      except OSError:
         raise Exception( "Unable to open config file %s" % configFile )

      beginCrc = False
      crc = 0
      count = 0
      for line in f:
         parsedLine = ''.join( filter(
             lambda x: x in '0123456789ABCDEFabcdef', line ) )
         code = parsedLine[6:8]
         data = parsedLine[8:-2]
         if beginCrc and count != 357:
            if count == 0:
               dataCopy = '00'+data[2:]
               dataStr = ''.join( [ chr( int(dataCopy[i:i+2], 16) ) \
                              for i in range(0,len(dataCopy), 2 ) ] )
            elif count == 318: # line 599. Assume all zeros when computing CRC.
               data = '00000000'
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            else:
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            crc = zlib.crc32( dataStr, crc ) & 0xffffffff
            count += 1
         if code == self.configPointerCode  and \
            data in [ self.configPointerVal1, self.configPointerVal2 ]:
            beginCrc = True
      assert beginCrc, 'OTP START string not found in hex file'
      return '%08X' % crc

   @property
   def availableConfigSlots( self ):
      return self.dmaHam.read( 0xC2 )

   def configCrcMatchesDeviceCrc( self, configFile ):
      assert configFile,  "need to specify config file"
      try:
         f = open( configFile )
      except OSError:
         raise AssertionError( "Unable to open config file %s" % configFile )

      # Get the line with the CRC for the image
      configCrc = ''.join( filter(lambda x: x in '0123456789ABCDEFabcdef',
                                  f.readlines()[599]) )
      configCrc = int( configCrc[8:-2], 16 )
      f.close()

      deviceCrc = self.dmaHam.read( 0x3f )
      deviceCrc = _byteReverse( deviceCrc )
      #If crc read from device matches crc in config, image is up to date
      print( "ISL68226 CRC: {}, {} CRC: {}".format(
             deviceCrc, configFile, configCrc ) )
      return bool( deviceCrc == configCrc )

   def programConfig( self, configFile, force=True, skipIfRovProgrammed=True ):
      failed = 0
      assert configFile,  "need to specify config file"

      if not force:
         print( "Must specify --force to program device.\nThis will consume" \
                      " a config slot on the device. Be sure this is what you want" \
                      " to do" )
         return 1

      availableConfigSlots = self.availableConfigSlots

      #Dont program and waste another OTP if the config already matches
      if self.configCrcMatchesDeviceCrc( configFile ):
         print( "Config CRC and Device CRC matches, skipping programming!" )
         exit(0)

      if availableConfigSlots < 20 and skipIfRovProgrammed:
         print( "Device has been programmed previously" )
         print( "Since device has less than 20 programming cycles left, "
                "please contact Arista for support." )
         exit(0)

      #Make sure there are available config slots in memory so that new image can
      #be programmed properly
      #Don't let boards with 2 or less config slots available make their way to
      #the field to stay conservative. If less than 2, the part should be replaced
      if availableConfigSlots <= 2:
         errMsg = 'ISL68226 ERROR: ' + \
            'No more config space left on device! Contact Arista immediately'
         raise AssertionError( errMsg )

      try:
         f = open( configFile )
      except OSError:
         raise AssertionError( "Unable to open config file %s" % configFile )
      deviceIdCheckSuccessful = False
      deviceRevCheckSuccessful = False
      headerGood = False
      with f:
         for line in f:
            parsedLine = ''.join( filter(
                lambda x: x in '0123456789ABCDEFabcdef', line ) )
            if self.dryRun:
               # DEANK
               print( f'Parsed Line {parsedLine}' )
            if deviceIdCheckSuccessful and deviceRevCheckSuccessful:
               headerGood = True

            recordType = parsedLine[0:2]
            byteCount = parsedLine[2:4]
            code = parsedLine[6:8]
            data = parsedLine[8:-2]

            #recordType 49 indicates we are reading the header
            if recordType == '49':
               #Ignore 490A and 490B though
               if byteCount == '0A' or byteCount == '0B':
                  pass
               #check icDeviceId and icDeviceRev are equal
               elif code == 'AD':
                  deviceIdCheckSuccessful = True
               elif code == 'AE':
                  deviceRevCheckSuccessful = True

            #recordType 00 means data written to HW
            elif headerGood and recordType == '00':
               dataLong = int( data, 16 )
               numBytes = sum( divmod( len( data ), 2 ) )
               dataLong = packLong( dataLong, 'big', numBytes )
               if self.dryRun:
                  print( "DRY RUN: writeSeq {}, {}".format(
                         int( code, 16 ), [ str(x) for x in dataLong ] ) )
               else:
                  self.ham.writeSequenceStr( int( code, 16 ), dataLong )
               time.sleep(10e-3)
            else:
               assert 0

      time.sleep( 5 )

      programmerStatusGood = self.dmaHam.read( 0x0707 )

      if programmerStatusGood & 0x1:
         print( 'ISL68226 programmerStatusGood' )
      else:
         failed += 1
         print( "FAILED: Programmer Status: 0x%x" % programmerStatusGood )
         if programmerStatusGood & 0x100:
            print( "Failed: No More OTP Banks" )
         if programmerStatusGood & 0x40:
            print( "Failed: CRC Mismatch on OTP" )
         if programmerStatusGood & 0x10:
            print( "Failed: CRC Mismatch in Config Data" )
         if programmerStatusGood & 0x1:
            print( "Failed: Device Busy" )

      #Arista Applications always will override bank 0
      bankStatusGood = self.dmaHam.read( 0x0709 )
      currentBankStatus = bankStatusGood & 0xf
      #0 means bank was unwritten, 1 means bank was written successfully
      #anything else indicates bank was corrupted
      try:
         assert currentBankStatus <= 1
      except AssertionError:
         failed += 1
         print( "Failed  Bank status: 0x%x" % ( currentBankStatus ) )

      return failed

class Raa228228:
   dmaAddrReg = 0xC7
   dmaDataReg = 0xC5
   chipDesc = "RAA228228"
   configPointerCode = 'C6'
   configPointerVals = [ '275759A5' ]
   projectCrcLineNum = 526

   def __init__( self, busId, address, initHam=False, dryRun=True ):
      self.description = self.chipDesc
      self.dmaHam = None
      self.dryRun = dryRun
      if initHam:
         self.ham = LinuxSmbusHam( busId, address )
         self.dmaHam = DmaIndirectHam( self.ham, self.dmaAddrReg, self.dmaDataReg )

   def calculateHexFileCrc( self, configFile ):
      ''' Returns CRC of a hex file'''
      assert configFile,  "need to specify config file"
      try:
         f = open( configFile )
      except OSError:
         raise AssertionError( "Unable to open config file %s" % configFile )

      beginCrc = False
      crc = 0
      count = 0
      for line in f:
         parsedLine = ''.join( filter(
             lambda x: x in '0123456789ABCDEFabcdef', line ) )
         code = parsedLine[6:8]
         data = parsedLine[8:-2]
         if not beginCrc:
            if code == self.configPointerCode and data in self.configPointerVals:
               beginCrc = True
            continue
         if beginCrc and count != 308:
            if count == 0:
               dataCopy = '00'+data[2:]
               dataStr = ''.join( [ chr( int(dataCopy[i:i+2], 16) ) \
                              for i in range(0,len(dataCopy), 2 ) ] )
            elif count == 261: # line 526 Insert project CRC
               data = self.calculateProjectCrc(configFile)
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            else:
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            crc = zlib.crc32( dataStr, crc ) & 0xffffffff
            count += 1
      assert beginCrc, 'OTP START string not found in hex file'
      return '%08X' % _byteReverse( crc )

   def calculateProjectCrc( self, configFile ):
      ''' Returns the project CRC of a hex file '''
      assert configFile, "need to specify config file"
      try:
         f = open( configFile )
      except OSError:
         raise AssertionError( "Unable to open config file %s" % configFile )

      beginCrc = False
      crc = 0
      count = 0
      for line in f:
         # NOTE: count is postincremented while line indexing starts with 1
         parsedLine = ''.join( filter(
             lambda x: x in '0123456789ABCDEFabcdef', line ) )
         code = parsedLine[6:8]
         data = parsedLine[8:-2]
         if not beginCrc:
            if code == self.configPointerCode  and data in self.configPointerVals:
               beginCrc = True
            continue
         if beginCrc and count != 308:
            if count == 0:
               dataCopy = '00'+data[2:]
               dataStr = ''.join( [ chr( int(dataCopy[i:i+2], 16) ) \
                              for i in range(0,len(dataCopy), 2 ) ] )
            elif count == 261: # line 526. Assume all zeros when computing CRC.
               data = '00000000'
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            else:
               dataStr = ''.join( [ chr( int(data[i:i+2], 16) ) \
                              for i in range(0,len(data), 2 ) ] )
            crc = zlib.crc32( dataStr, crc ) & 0xffffffff
            count += 1
      assert beginCrc, 'OTP START string not found in hex file'
      return '%08X' % crc

   @property
   def availableConfigSlots( self ):
      return self.dmaHam.read( 0xC4 )

   def configCrcMatchesDeviceCrc( self, configFile ):
      assert configFile,  "need to specify config file"
      try:
         f = open( configFile )
      except OSError:
         raise AssertionError( "Unable to open config file %s" % configFile )

      # Get the line with the CRC for the image
      configCrc = ''.join(filter(lambda x: x in '0123456789ABCDEFabcdef',
                                  f.readlines()[self.projectCrcLineNum-1]))
      msg = "  {} File configCrc: {} {}".format(
                "RA228228", configCrc[8:-2], configCrc )
      configCrc = int( configCrc[8:-2], 16 )
      f.close()

      deviceCrc = self.dmaHam.read( 0x3c )
      deviceCrc = _byteReverse( deviceCrc )
      msg += ", Device CRC: 0x%x" % deviceCrc
      print( msg )
      # If crc read from device matches crc from config file,
      # we assume the device is up-to-date
      return bool( deviceCrc == configCrc )

   def programConfig( self, configFile, force=True, skipIfRovProgrammed=True ):
      failed = 0
      assert configFile,  "need to specify config file"

      if not force:
         print( "Must specify --force to program device.\nThis will consume" \
                      " a config slot on the device. Be sure this is what you want" \
                      " to do" )
         return 1

      availableConfigSlots = self.availableConfigSlots

      #Dont program and waste another OTP if the config already matches
      if self.configCrcMatchesDeviceCrc( configFile ):
         print( "Config CRC and Device CRC matches, skipping programming!" )
         exit(0)

      if availableConfigSlots < 20 and skipIfRovProgrammed:
         print( "Device has been programmed previously" )
         print( "Since device has less than 20 programming cycles left, "
                "please contact Arista for support." )
         exit(0)

      #Make sure there are available config slots in memory so that new image can
      #be programmed properly
      #Don't let boards with 2 or less config slots available make their way to
      #the field to stay conservative. If less than 2, the part should be replaced
      if availableConfigSlots <= 2:
         errMsg = 'RA228228 ERROR: ' + \
            'No more config space left on device! Contact Arista immediately'
         raise AssertionError( errMsg )

      try:
         f = open( configFile )
      except OSError:
         raise AssertionError( "Unable to open config file %s" % configFile )
      deviceIdCheckSuccessful = False
      deviceRevCheckSuccessful = False
      headerGood = False
      with f:
         for line in f:
            parsedLine = ''.join( filter(
                lambda x: x in '0123456789ABCDEFabcdef', line ) )
            if self.dryRun:
               # DEANK
               print( f'Parsed Line {parsedLine}' )
            recordType = parsedLine[ 0 : 2 ]
            byteCount = parsedLine[2:4]
            code = parsedLine[6:8]
            data = parsedLine[8:-2]

            if recordType == '49': # header
               if byteCount == '0A' or byteCount == '0B':
                  pass # ignore header 490A and 490B
               #check icDeviceId and icDeviceRev are equal
               elif code == 'AD':
                  deviceIdCheckSuccessful = True
               elif code == 'AE':
                  deviceRevCheckSuccessful = True

               if deviceIdCheckSuccessful and deviceRevCheckSuccessful:
                  headerGood = True

            # record type 00 is data to be written to HW
            elif headerGood and recordType == '00':
               dataLong = int( data, 16 )
               numBytes = sum( divmod( len( data ), 2 ) )
               dataLong = packLong( dataLong, 'big', numBytes )
               if self.dryRun:
                  print( "DRY RUN: writeSeq {}, {}".format(
                         int( code, 16 ), dataLong ) )
               else:
                  self.ham.writeSequenceStr( int( code, 16 ), dataLong )
               time.sleep(10e-3)
            else:
               assert 0
      time.sleep( 5 )

      # Arista applications always will override bank 0
      bankStatusGood = self.dmaHam.read( 0x0709 )
      currentBankStatus = bankStatusGood & 0xf
      if currentBankStatus == 1:
         print( 'RA228228 programmerStatusGood' )
      else:
         failed += 1
         msg = "Failed Bank status: 0x%x" % ( currentBankStatus )
         if currentBankStatus == 4:
            msg += " -- CRC mismatch OTP"
         elif currentBankStatus == 8:
            msg += " -- CRC mismatch RAM"
         elif currentBankStatus == 0:
            msg += " -- Bank unwritten"
         print( msg )

      print( "DEBUG: bankStatusGood: 0x%x, currentBankStatus: 0x%x", \
         bankStatusGood, currentBankStatus )
      print( "Programing completed, powerCycle for config to properly load\n" \
         "%s Available config slots: %d", "RAA228228", availableConfigSlots - 1 )
      return failed

def parseArgs( argv ):
   parser = argparse.ArgumentParser(
      description='elbert program ISL68226/RA228228 tool.' )
   parser.add_argument( '-c', '--chip', required=True,
         help='target chip type.' )
   parser.add_argument( '-b', '--bus', required=True,
         help='target chip I2C Bus number.' )
   parser.add_argument( '-a', '--address', required=True,
         help='target chip I2C Address in hex.' )
   parser.add_argument( '--config', required=True,
         help='path to config file to program.' )
   parser.add_argument( '-d', '--dryrun', action='store_true',
         help='Dry run, will not perform any writes' )

   args = parser.parse_args( argv )
   return args

def main( args ):
   args = parseArgs( args )

   # Create Device HAM
   device = None
   if args.chip.lower() == 'isl68226':
      device = Isl68226( int( args.bus, 16 ), int( args.address, 16 ),
                         initHam=True, dryRun=args.dryrun )
   elif args.chip.lower() == 'ra228228':
      assert 0, 'Device not supported'
      #  device = Raa228228( int( args.bus, 16 ), int( args.address, 16 ),
                          #  initHam=True, dryRun=args.dryrun )
   else:
      assert 0, 'Chip type not supported'

   #  print( 'read 0x0: {}'.format( device.ham.read8( 0x0 ) ) )
   #  print( 'write 0x0 0x0: {}'.format( device.ham.write8( 0x0, 0x0 )) )
   #  print( 'read 0x0: {}'.format( device.ham.read8( 0x0 ) ) )

   currentSlots = device.availableConfigSlots
   print( f'Current Slots before programming: {currentSlots}' )
   rc = device.programConfig( args.config )

   if rc != 0:
      print( 'Programming ISL68226 failed!' )
      exit(1)
   else:
      print( 'Programming ISL68226 successful!' )
      print( 'Please powercycle for changes to take effect' )


if __name__ == '__main__':
   sys.exit( main( sys.argv[ 1 : ] ) )
