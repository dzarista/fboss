#!/bin/sh

flash="/dev/flash1"
flash_backup="/tmp/flash-backup"
script="./flash_erase_modified"

block_size=4096

trap cleanup INT TERM QUIT EXIT

usage(){
   echo "usage: flash_checker.sh [--flash 0|1]"
   echo "    --flash: which flash to check (0 or 1, default 1)"
   exit 1
}

backup_flash(){
   echo "Backing up $flash"
   dd if="$flash" of="$flash_backup" bs="$block_size" \
      count=$((128 * 1024 * 1024 / block_size)) 2>/dev/null
   # shellcheck disable=SC2181
   if [ $? -ne 0 ]; then
      echo "Failed to back up $flash"
      exit 1
   fi
}

write_back_flash(){
   echo "Restoring $flash"
   dd if="$flash_backup" of="$flash" bs="$block_size" \
      count=$((128 * 1024 * 1024 / block_size)) 2>/dev/null
   # shellcheck disable=SC2181
   if [ $? -ne 0 ]; then
      echo "Failed to write back $flash"
      exit 1
   fi
   rm -f "$flash_backup"
}

cleanup(){
   echo "Running cleanup"
   if [ -e "$flash_backup" ]; then
      write_back_flash
   fi
}

do_run(){
   backup_flash
   "$script" "$flash"
}

if ! [ -f "$script" ]; then
   echo "Missing script: $script"
   exit 1
fi

if [ "$1" == "--flash" ]; then
   if [ "$2" -eq 0 ]; then
      flash="/dev/flash0"
   elif [ "$2" -ne 1 ]; then
      echo "--flash argument must be 0 or 1"
      exit 1
   fi
elif [ $# -ne 0 ]; then
   usage
fi

do_run

